package com.br.vivo.exclusaoCDR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExclusaoCdrApplicationTests {

	@Test
	void contextLoads() {
	}

}
