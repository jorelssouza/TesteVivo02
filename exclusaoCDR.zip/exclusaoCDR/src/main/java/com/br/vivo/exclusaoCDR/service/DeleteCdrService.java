package com.br.vivo.exclusaoCDR.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.vivo.exclusaoCDR.entity.Cdr;
import com.br.vivo.exclusaoCDR.repository.CdrRepository;

@Service
public class DeleteCdrService {
	
	@Autowired
	private CdrRepository cdrRepository;
	
	public void execute(Cdr cdr){
		//log.info("Excluindo CDR Id: " cdr.getId());
		
		cdrRepository.deleteById(cdr.getId());
		
		//log.info("CDR excluida");
		
	}

}
