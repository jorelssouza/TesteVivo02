package com.br.vivo.exclusaoCDR.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name= "registro_fatura_cliente")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
public class Cdr {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="descricaoservico", length = 50, nullable = false)
	private String descricaoServico;
	
	@Column(name="tiposervico", length = 3, nullable = false)
	private String tipoServico;

	@Column(name="valor")
	private BigDecimal valor;
	
	@Column(name="dataHora", length = 12, nullable = false)
	private Date dataHora;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescricaoServico() {
		return descricaoServico;
	}

	public void setDescricaoServico(String descricaoServico) {
		this.descricaoServico = descricaoServico;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(String tipoServico) {
		this.tipoServico = tipoServico;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public Date getDataHora() {
		return dataHora;
	}

	public void setDataHora(Date dataHora) {
		this.dataHora = dataHora;
	}

}
