package com.br.vivo.exclusaoCDR.dto;

import java.math.BigDecimal;
import java.util.Date;
import javax.validation.constraints.NotEmpty;
import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CdrDTO {
	
	private Long id;
	
	//@NotNull(message ="Descricao Servico é Obrigatorio");
	//@NotEmpty(message ="Descricao Servico é Obrigatorio");
	private String descricaoServico;
	
	//@NotNull(message ="Data Hora é Obrigatorio");
	//@NotEmpty(message ="Data Hora é Obrigatorio");
	private Date dataHora;
	
	//@NotNull(message ="Tipo servico é Obrigatorio");
	//@NotEmpty(message ="Tipo servico é Obrigatorio");
	private String tipoServico;

	//@NotNull(message ="Valor é Obrigatorio");
	//@NotEmpty(message ="Valor é Obrigatorio");
	private BigDecimal valor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescricaoServico() {
		return descricaoServico;
	}

	public void setDescricaoServico(String descricaoServico) {
		this.descricaoServico = descricaoServico;
	}

	public Date getDataHora() {
		return dataHora;
	}

	public void setDataHora(Date dataHora) {
		this.dataHora = dataHora;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(String tipoServico) {
		this.tipoServico = tipoServico;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	
	
	
	
	
}

