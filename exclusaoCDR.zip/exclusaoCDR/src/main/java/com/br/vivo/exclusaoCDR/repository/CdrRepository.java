package com.br.vivo.exclusaoCDR.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.br.vivo.exclusaoCDR.entity.Cdr;

@Repository
public interface CdrRepository  extends CrudRepository<Cdr, Long> {

}
