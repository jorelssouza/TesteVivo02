package com.br.vivo.exclusaoCDR.http;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.br.vivo.exclusaoCDR.service.DeleteCdrService;
import com.br.vivo.exclusaoCDR.entity.Cdr;
import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
public class CdrResource {
	
	@Autowired(required=true)
	private DeleteCdrService deleteCdrService;
	
	@PostMapping("wayneMobile/excluirCdr")
	public void setCliente(@Valid  @RequestBody Cdr cdr){
		
		deleteCdrService.execute(cdr);
		
	}	
	
	
}
