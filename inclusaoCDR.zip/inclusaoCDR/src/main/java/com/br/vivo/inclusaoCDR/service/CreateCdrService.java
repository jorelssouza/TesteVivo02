package com.br.vivo.inclusaoCDR.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.vivo.inclusaoCDR.entity.Cdr;
import com.br.vivo.inclusaoCDR.repository.CdrRepository;

@Service
public class CreateCdrService {

	@Autowired
	private CdrRepository cdrRepository;
	
	public void incluir(Cdr cdr){
//		log.info("Incluindo CDR.");
		cdrRepository.save(cdr);
//		log.info("Cliente Incluído. ID: " cdr.getId());
		
	}
	
}
