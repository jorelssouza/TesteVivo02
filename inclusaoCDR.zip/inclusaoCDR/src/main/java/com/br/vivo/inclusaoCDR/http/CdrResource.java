package com.br.vivo.inclusaoCDR.http;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.br.vivo.inclusaoCDR.dto.CdrDTO;
import com.br.vivo.inclusaoCDR.entity.Cdr;
import com.br.vivo.inclusaoCDR.service.CreateCdrService;
import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
public class CdrResource {
	
	@Autowired(required=true)
	private CreateCdrService createCdrService;
		
	@PostMapping("wayneMobile/incluirCdr")
	public void setCliente(@Valid  @RequestBody CdrDTO cdrDTO){
		
		Date dataHora = new Date();
		
		Cdr cdr = new Cdr();
		cdr.setDescricaoServico(cdrDTO.getDescricaoServico());
		cdr.setDataHora(dataHora);
		cdr.setTipoServico(cdrDTO.getTipoServico());
		cdr.setValor(cdrDTO.getValor());
		
		createCdrService.incluir(cdr);
		
	}

}
