package com.br.vivo.inclusaoCDR.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.br.vivo.inclusaoCDR.entity.Cdr;

@Repository
public interface CdrRepository  extends CrudRepository<Cdr, Long> {
	
	
}
