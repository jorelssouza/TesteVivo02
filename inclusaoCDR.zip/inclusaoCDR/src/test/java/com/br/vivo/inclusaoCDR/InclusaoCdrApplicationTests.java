package com.br.vivo.inclusaoCDR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InclusaoCdrApplicationTests {

	@Test
	void contextLoads() {
	}

}
