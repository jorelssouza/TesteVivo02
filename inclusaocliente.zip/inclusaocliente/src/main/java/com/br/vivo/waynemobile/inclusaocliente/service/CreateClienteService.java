package com.br.vivo.waynemobile.inclusaocliente.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.br.vivo.waynemobile.inclusaocliente.entity.Cliente;
import com.br.vivo.waynemobile.inclusaocliente.repository.ClienteRepository;
import lombok.extern.log4j.Log4j2;

@Service
public class CreateClienteService {

	@Autowired
	private ClienteRepository clienteRepository;
	
	public void incluir(Cliente cliente){
		//log.info("Incluindo Cliente.");
		
		clienteRepository.save(cliente);
		
		//log.info("Cliente Incluído. ID: " cliente.getId());
		
	}
	
}
