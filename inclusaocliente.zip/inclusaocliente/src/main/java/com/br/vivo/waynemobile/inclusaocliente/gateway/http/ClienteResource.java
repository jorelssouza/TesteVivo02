package com.br.vivo.waynemobile.inclusaocliente.gateway.http;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.br.vivo.waynemobile.inclusaocliente.entity.Cliente;
import com.br.vivo.waynemobile.inclusaocliente.gateway.dto.ClienteDTO;
import com.br.vivo.waynemobile.inclusaocliente.service.CreateClienteService;
import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
public class ClienteResource {
	
	@Autowired(required=true)
	private CreateClienteService createClienteService;
	
	@PostMapping("wayneMobile/incluirCliente")
	public void setCliente(@Valid  @RequestBody ClienteDTO clienteDTO){
		//log.info("Nome do cliente é: "+ clienteDTO.getName());
		
		Cliente cliente = new Cliente();
		
		cliente.setCelular(clienteDTO.getCelular());
		cliente.setCpfCnpj(clienteDTO.getCpfCnpj());
		cliente.setDdd(clienteDTO.getDdd());
		cliente.setName(clienteDTO.getName());
		
		createClienteService.incluir(cliente);
		
	}
	
//	@GetMapping("wayneMobile/cliente")
//	public ClienteDTO getCliente() {
//		return ClienteDTO.builder().id()clone().; 
//		
//		
//	}

}
