package com.br.vivo.waynemobile.inclusaocliente.gateway.dto;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ClienteDTO {
	
	private Long id;
	
	//@NotNull(message ="Nome é Obrigatorio");
	//@NotEmpty(message ="Nome é Obrigatorio");
	private String name;
	
	//@NotNull(message ="CpfCnpj é Obrigatorio");
	//@NotEmpty(message ="CpfCnpj é Obrigatorio");
	private String cpfCnpj;
	
	private String ddd;
	
	private String celular;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}
	
}
