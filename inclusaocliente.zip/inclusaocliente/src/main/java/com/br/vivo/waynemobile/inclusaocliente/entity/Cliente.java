package com.br.vivo.waynemobile.inclusaocliente.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name= "cliente_vivo")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
public class Cliente {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="name", length = 255, nullable = false)
	private String name;
	
	@Column(name="cpfCnpj", length = 14, nullable = false)
	private String cpfCnpj;
	
	@Column(name="ddd")
	private String ddd;
	
	@Column(name="celular", length = 9, nullable = false)
	private String celular;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}
	
}
