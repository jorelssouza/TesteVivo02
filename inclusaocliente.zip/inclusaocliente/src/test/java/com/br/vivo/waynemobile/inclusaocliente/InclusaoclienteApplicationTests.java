package com.br.vivo.waynemobile.inclusaocliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InclusaoclienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
